
package Tela;

import javax.swing.JOptionPane;

public class TelaPrincipal {
    

    
 public void EntradadeDados(){

}
 
 public void SaidadeDados(){
 }
}