package negocio;
import dao.Arquivo;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JFrame;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

public class TelaSimples extends JFrame {
    public JTextField caixaTexto1;
    public JTextField caixaTexto2;
    public JTextField caixaTexto3;
    public JTextField caixaTexto4;
    public JTextField caixaTexto5;
    public JTextField caixaTexto6;
    public JTextField caixaTexto7;
    public JTextField caixaTexto8;
    public JTextField caixaTexto9;
    
    JButton botaoCalcular = new JButton ("Calcular");
    JButton botaoLimpar = new JButton ("Limpar");

public TelaSimples(){
    
    super("Sorveteria Blue                           -  Gabrielle de Souza");
    
    Container tela = getContentPane();
    tela.setLayout(null);
  
    ImageIcon imagem = new ImageIcon(TelaSimples.class.getResource("sorveteazulmttop.jpg"));
    imagem.setImage(imagem.getImage().getScaledInstance(300, 175, 0));
    JLabel label10 = new JLabel(imagem);
    label10.setBounds(0, 10, 400, 200);
    
   // Icon imagem = new ImageIcon ("C:\\Users\\gabik\\Pictures\\sorveteazulmttop.jpg");
    //JLabel label10 = new JLabel (imagem);
    //label10.setBounds(0, 10, 400, 200);
   
    JLabel label3 = new JLabel("Tipo de sorvete");
    label3.setBounds(0,100,200,250);
    
    JLabel label4 = new JLabel("Quantidade");
    label4.setBounds(130, 100, 200, 250);
    
    JLabel label6 = new JLabel("Preço Unitario");
    label6.setBounds(250, 100, 200, 250);
     
    JLabel label8 = new JLabel("Picolé de frutas ");
    label8.setBounds(0, 120, 200, 300);
    
    caixaTexto1 = new JTextField("");
    caixaTexto1.setBounds(130, 255, 50, 30);
    
    caixaTexto2 = new JTextField("R$1,25");
    caixaTexto2.setBounds(250, 255, 50, 30);
    caixaTexto2.setEditable(false);
    
    JLabel label13 = new JLabel("Chocolate/fruta");
    label13.setBounds(0, 45,500, 550);
    
    caixaTexto3 = new JTextField(" ");
    caixaTexto3.setBounds(130, 310, 50, 30);
      
    caixaTexto4 = new JTextField("R$1,50");
    caixaTexto4.setBounds(250, 310, 50, 30);
    caixaTexto4.setEditable(false);
   
    JLabel label17 = new JLabel("Bola");
    label17.setBounds(0, 95,500, 550);
    
    caixaTexto5 =  new JTextField("  ");
    caixaTexto5.setBounds(130, 360, 50, 30);
    
    caixaTexto6 = new JTextField("R$2,00");
    caixaTexto6.setBounds(250, 360, 50, 30);
    caixaTexto6.setEditable(false);
    
    JLabel label21 = new JLabel("Pote de 2 litros");
    label21.setBounds(0, 150, 500, 550);
    
    caixaTexto7 = new JTextField("  ");
    caixaTexto7.setBounds(130, 410, 50, 30);
   
    caixaTexto8 = new JTextField("R$15,75");
    caixaTexto8.setBounds(250, 410, 50, 30);
    caixaTexto8.setEditable(false);
    
    JLabel label25 = new JLabel("Total: ");
    label25.setBounds(0, 210, 500, 550);
    
    
    caixaTexto9 = new JTextField("        ");
    caixaTexto9.setBounds(130, 470, 50, 30);
    caixaTexto9.setEditable(false);
    
    botaoCalcular.setBounds(10,600,200,50);
    botaoLimpar.setBounds(350,600,200,50);
    botaoCalcular.addActionListener(new ActionListener() {
         @Override
     public void actionPerformed(ActionEvent ae) {
        try {
        String itemString = caixaTexto1.getText();
        int item = Integer.parseInt(itemString);
                        
        String itemString2 = caixaTexto3.getText(); 
        int item2 = Integer.parseInt(itemString2);
                        
        String itemString3 = caixaTexto5.getText(); 
        int item3 = Integer.parseInt(itemString3);
                        
        String itemString4 = caixaTexto7.getText(); 
        int item4 = Integer.parseInt(itemString4);
                        
        double totalReal = item*1.25 + item2*1.5 + item3*2 + item4*15.75;
        String totalString;
                            
        if (item>=0 && item2>=0 && item3>=0 && item4>=0) {
        totalString = "R$" + totalReal;
        botaoCalcular.setText(totalString);
        Arquivo leitura = new Arquivo();
        leitura.gravarArquivo(totalString);
        caixaTexto9.setText(totalString);
        
       
      } else {
        JOptionPane.showMessageDialog(null, "Insira valores válidos.", "Erro!", JOptionPane.ERROR_MESSAGE);
        }
          }
       catch(RuntimeException ex) {
          JOptionPane.showMessageDialog(null, "Insira valores válidos.", "Erro!", JOptionPane.ERROR_MESSAGE);
          }}
                });
        
     botaoLimpar.addActionListener(
     new ActionListener() {
       @Override
      public void actionPerformed(ActionEvent ae) {
        caixaTexto1.setText("");
        caixaTexto3.setText("");
        caixaTexto5.setText("");
        caixaTexto7.setText("");
        caixaTexto9.setText("");
                    }
                }
        );


  //Atalhos no botão 
    botaoCalcular.setMnemonic(KeyEvent.VK_B);
    botaoLimpar.setMnemonic(KeyEvent.VK_A);

    
    tela.add(botaoLimpar); 
    tela.add(label10);
    tela.add(label3);
    tela.add(label4);
    tela.add(label6);
    tela.add(label8);
    tela.add(caixaTexto1);
    tela.add(caixaTexto2);
    tela.add(label13);
    tela.add(caixaTexto3);
    tela.add(caixaTexto4);
    tela.add(label17);
    tela.add(caixaTexto5);
    tela.add(caixaTexto6);
    tela.add(label21);
    tela.add(caixaTexto7);
    tela.add(caixaTexto8);
    tela.add(label25);
    tela.add(caixaTexto9);
    tela.add(botaoCalcular);
   

    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setSize(570, 700);
    this.setVisible(true);
    this.setResizable(false);
    this.setLocationRelativeTo(null);
     
}
    public class Produtos{
        private String picolefrutas;
        private String poteDoisL;
        private 


}

    }


