package dao;


import java.io.*;
import java.io.FileReader;
import java.io.BufferedReader;

public class Arquivo {
    FileReader fileR;
    BufferedReader buffR;
    FileWriter fileW;
    BufferedWriter buffW;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
    String linha= "\n ";
    String conteudo= " ";
    
    
    
    public void gravarArquivo(String texto){
        try{
        fileW=new FileWriter("C:\\Users\\gabik\\Documents\\NetBeansProjects\\Sorveteria.txt", true);
        
        buffW = new BufferedWriter(fileW);        
        buffW.write("NOTA FISCAL DA COMPRA:  \r\n   Total da compra:"  +texto +  " \r\n");        
        buffW.close();        
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }   
    
    public String lerArquivo(){
        try{
        fileR= new FileReader("C:\\Users\\gabik\\Documents\\NetBeansProjects\\Sorveteria.txt");
        buffR= new BufferedReader(fileR);
        
        linha= buffR.readLine();
        
        while(linha!=null){
            conteudo+=linha + "\n \n \n \r ";
            linha= buffR.readLine();
        }
        fileR.close();
        return conteudo;
        
        }
        catch(FileNotFoundException e){
            return e.getMessage();
        }
        
        catch(IOException e){
            return e.getMessage();
        }
    }
}
